// ============================================================================
// LiquidGlass Explorer - Aplicación Principal
// ============================================================================
// Punto de entrada de la aplicación que carga la configuración e inyecta
// el DLL en Windows Explorer para aplicar efectos Liquid Glass.
// ============================================================================

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include "injector.h"
#include "config.h"

// Declaraciones forward
DWORD GetExplorerPID();

// ============================================================================
// FUNCIÓN PRINCIPAL
// ============================================================================
int main(int argc, char* argv[]) {
    // Verificar si se ejecuta como administrador
    if (!IsUserAdmin()) {
        MessageBoxA(
            NULL,
            "Esta aplicación requiere permisos de administrador.\n\n"
            "Por favor, ejecuta como administrador.",
            "Error - Permisos insuficientes",
            MB_ICONERROR | MB_OK
        );
        return 1;
    }

    OutputDebugStringA("[LiquidGlass] Iniciando aplicación...\n");

    // ========================================================================
    // PASO 1: Cargar configuración
    // ========================================================================
    Config cfg;
    if (!cfg.Load("config/liquidglass.ini")) {
        MessageBoxA(
            NULL,
            "No se pudo cargar la configuración.\n"
            "Asegúrate de que liquidglass.ini existe en la carpeta config/",
            "Error - Configuración",
            MB_ICONERROR | MB_OK
        );
        return 1;
    }

    OutputDebugStringA("[LiquidGlass] Configuración cargada correctamente\n");

    // ========================================================================
    // PASO 2: Obtener PID de explorer.exe
    // ========================================================================
    DWORD pid = GetExplorerPID();
    if (pid == 0) {
        MessageBoxA(
            NULL,
            "No se encontró explorer.exe en ejecución.\n\n"
            "Por favor, asegúrate de que Windows Explorer está abierto.",
            "Error - Explorer no encontrado",
            MB_ICONERROR | MB_OK
        );
        return 1;
    }

    char pidMsg[256];
    sprintf_s(pidMsg, sizeof(pidMsg), 
        "[LiquidGlass] Explorer.exe encontrado (PID: %lu)\n", pid);
    OutputDebugStringA(pidMsg);

    // ========================================================================
    // PASO 3: Preparar ruta del DLL
    // ========================================================================
    char dllPath[MAX_PATH] = {};
    
    // Intentar obtener la ruta absoluta del DLL
    if (!GetFullPathNameA("LiquidGlass.dll", MAX_PATH, dllPath, NULL)) {
        MessageBoxA(
            NULL,
            "No se pudo determinar la ruta del DLL.\n"
            "Asegúrate de que LiquidGlass.dll está en la carpeta actual.",
            "Error - DLL no encontrado",
            MB_ICONERROR | MB_OK
        );
        return 1;
    }

    // Verificar que el archivo existe
    if (GetFileAttributesA(dllPath) == INVALID_FILE_ATTRIBUTES) {
        char errorMsg[512];
        sprintf_s(errorMsg, sizeof(errorMsg),
            "El archivo DLL no existe:\n\n%s\n\n"
            "Por favor, asegúrate de que el archivo está en la ubicación correcta.",
            dllPath);
        MessageBoxA(NULL, errorMsg, "Error - Archivo no encontrado", MB_ICONERROR | MB_OK);
        return 1;
    }

    char dllMsg[MAX_PATH + 50];
    sprintf_s(dllMsg, sizeof(dllMsg), "[LiquidGlass] Ruta del DLL: %s\n", dllPath);
    OutputDebugStringA(dllMsg);

    // ========================================================================
    // PASO 4: Inyectar DLL en Explorer
    // ========================================================================
    if (!InjectDLL(pid, dllPath)) {
        MessageBoxA(
            NULL,
            "No se pudo inyectar el DLL en explorer.exe.\n\n"
            "Posibles causas:\n"
            "  - Permisos insuficientes\n"
            "  - Incompatibilidad de arquitectura (32/64 bits)\n"
            "  - Explorer se cerró durante la inyección",
            "Error - Inyección fallida",
            MB_ICONERROR | MB_OK
        );
        return 1;
    }

    OutputDebugStringA("[LiquidGlass] DLL inyectado exitosamente\n");

    // ========================================================================
    // PASO 5: Confirmación de éxito
    // ========================================================================
    MessageBoxA(
        NULL,
        "✓ LiquidGlass cargado correctamente en Explorer.\n\n"
        "El efecto Liquid Glass está activo.\n"
        "Abre nuevas ventanas de Explorer para ver los cambios.",
        "Éxito",
        MB_ICONINFORMATION | MB_OK
    );

    OutputDebugStringA("[LiquidGlass] Aplicación finalizada correctamente\n");
    return 0;
}

// ============================================================================
// FUNCIÓN AUXILIAR: Verificar permisos de administrador
// ============================================================================
BOOL IsUserAdmin(void) {
    BOOL fIsAdmin = FALSE;
    HANDLE hToken = NULL;
    TOKEN_ELEVATION Elevation;
    DWORD cbSize = sizeof(TOKEN_ELEVATION);

    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        return FALSE;
    }

    if (GetTokenInformation(hToken, TokenElevation, &Elevation, sizeof(Elevation), &cbSize)) {
        fIsAdmin = (Elevation.TokenIsElevated != 0);
    }

    if (hToken) {
        CloseHandle(hToken);
    }

    return fIsAdmin;
}

// ============================================================================
// FUNCIÓN AUXILIAR: Obtener PID de explorer.exe
// ============================================================================
DWORD GetExplorerPID() {
    PROCESSENTRY32 entry = {};
    entry.dwSize = sizeof(PROCESSENTRY32);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }

    if (Process32First(snapshot, &entry)) {
        do {
            if (strcmp(entry.szExeFile, "explorer.exe") == 0) {
                CloseHandle(snapshot);
                return entry.th32ProcessID;
            }
        } while (Process32Next(snapshot, &entry));
    }

    CloseHandle(snapshot);
    return 0;
}