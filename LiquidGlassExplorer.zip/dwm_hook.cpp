// ============================================================================
// LiquidGlass Explorer - Implementación del Hook DWM
// ============================================================================
// Implementa las funciones para aplicar efectos Liquid Glass a ventanas
// de Windows Explorer mediante hooks en el Desktop Window Manager.
// ============================================================================

#include "dwm_hook.h"
#include <stdio.h>

// ============================================================================
// DEFINICIONES DE ESTRUCTURAS Y CONSTANTES
// ============================================================================

/// Estructura para política de acento visual (efecto acrílico/blur)
typedef struct _ACCENT_POLICY {
    int AccentState;    ///< Estado del acento (0=deshabilitado, 4=acrílico)
    int AccentFlags;    ///< Flags adicionales
    int GradientColor;  ///< Color de gradiente (formato ARGB)
    int AnimationId;    ///< ID de animación
} ACCENT_POLICY;

/// Estructura para datos de composición de ventana
typedef struct _WINDOWCOMPOSITIONATTRIBDATA {
    int Attrib;         ///< Atributo a establecer
    PVOID pvData;       ///< Puntero a los datos
    SIZE_T cbData;      ///< Tamaño de los datos
} WINDOWCOMPOSITIONATTRIBDATA;

/// Puntero a función SetWindowCompositionAttribute (no exportada públicamente)
typedef BOOL(WINAPI* pSetWindowCompositionAttribute)(HWND, WINDOWCOMPOSITIONATTRIBDATA*);

// ============================================================================
// CONSTANTES
// ============================================================================

/// Estados de acento disponibles
enum ACCENT_STATE {
    ACCENT_DISABLED = 0,              ///< Sin efecto
    ACCENT_ENABLE_GRADIENT = 1,       ///< Gradiente simple
    ACCENT_ENABLE_TRANSPARENTGRADIENT = 2, ///< Gradiente transparente
    ACCENT_ENABLE_BLURBEHIND = 3,     ///< Blur simple
    ACCENT_ENABLE_ACRYLICBLURBEHIND = 4, ///< Acrylic blur (Windows 10+)
    ACCENT_ENABLE_HOSTBACKDROP = 5,   ///< Host backdrop (Windows 11+)
    ACCENT_ENABLE_FLUENT_DARK = 6     ///< Fluent dark (Windows 11+)
};

/// Atributos de composición de ventana
enum WINDOW_COMPOSITION_ATTRIBUTE {
    WCA_UNDEFINED = -1,
    WCA_ACCENT_POLICY = 19             ///< Política de acento
};

// ============================================================================
// VARIABLES GLOBALES
// ============================================================================

/// Handle global del hook para gestión
HHOOK g_hHook = NULL;

/// Cache del puntero a función (evita búsquedas repetidas)
pSetWindowCompositionAttribute g_SetWindowCompositionAttribute = NULL;

// ============================================================================
// FUNCIÓN AUXILIAR: Inicializar SetWindowCompositionAttribute
// ============================================================================
static pSetWindowCompositionAttribute GetSetWindowCompositionAttribute() {
    if (g_SetWindowCompositionAttribute) {
        return g_SetWindowCompositionAttribute;
    }

    HMODULE hUser = LoadLibraryA("user32.dll");
    if (!hUser) {
        OutputDebugStringA("[DWM Hook] Error: No se pudo cargar user32.dll\n");
        return NULL;
    }

    pSetWindowCompositionAttribute func =
        (pSetWindowCompositionAttribute)GetProcAddress(hUser, "SetWindowCompositionAttribute");

    if (!func) {
        OutputDebugStringA("[DWM Hook] Error: SetWindowCompositionAttribute no encontrada\n");
        FreeLibrary(hUser);
        return NULL;
    }

    // No liberar hUser - se mantiene en memoria durante la vida de la aplicación
    g_SetWindowCompositionAttribute = func;
    return func;
}

// ============================================================================
// FUNCIÓN: ApplyLiquidGlass
// Aplica el efecto Liquid Glass a una ventana
// ============================================================================
void ApplyLiquidGlass(HWND hwnd) {
    if (!IsWindow(hwnd)) {
        OutputDebugStringA("[DWM Hook] Error: HWND inválido\n");
        return;
    }

    // ========================================================================
    // Obtener función SetWindowCompositionAttribute
    // ========================================================================
    pSetWindowCompositionAttribute SetWindowCompositionAttribute =
        GetSetWindowCompositionAttribute();

    if (!SetWindowCompositionAttribute) {
        OutputDebugStringA("[DWM Hook] Error: No se pudo obtener SetWindowCompositionAttribute\n");
        return;
    }

    // ========================================================================
    // Configurar política de acento (efecto acrílico)
    // ========================================================================
    ACCENT_POLICY policy = {};
    
    // Usar ACCENT_ENABLE_ACRYLICBLURBEHIND para Windows 10+
    // O ACCENT_ENABLE_BLURBEHIND para Windows 7/8
    policy.AccentState = ACCENT_ENABLE_ACRYLICBLURBEHIND;
    policy.AccentFlags = 0;
    
    // Color con transparencia: Alpha (150) + Color blanco (0xFFFFFF)
    // Formato: (Alpha << 24) | RGB
    policy.GradientColor = (150 << 24) | 0xFFFFFF;
    policy.AnimationId = 0;

    // ========================================================================
    // Crear estructura de datos de composición
    // ========================================================================
    WINDOWCOMPOSITIONATTRIBDATA data = {};
    data.Attrib = WCA_ACCENT_POLICY;
    data.pvData = &policy;
    data.cbData = sizeof(ACCENT_POLICY);

    // ========================================================================
    // Aplicar el efecto
    // ========================================================================
    BOOL result = SetWindowCompositionAttribute(hwnd, &data);

    if (result) {
        wchar_t msg[128];
        swprintf_s(msg, sizeof(msg) / sizeof(wchar_t),
            L"[DWM Hook] Liquid Glass aplicado a ventana (HWND: 0x%p)\n", hwnd);
        OutputDebugStringW(msg);
    } else {
        OutputDebugStringA("[DWM Hook] Advertencia: SetWindowCompositionAttribute retornó FALSE\n");
    }
}

// ============================================================================
// FUNCIÓN: HookProc
// Procedimiento de hook para interceptar mensajes de ventanas
// ============================================================================
LRESULT CALLBACK HookProc(int code, WPARAM wParam, LPARAM lParam) {
    // Solo procesar si code >= 0
    if (code < 0) {
        return CallNextHookEx(g_hHook, code, wParam, lParam);
    }

    // ========================================================================
    // Obtener información del mensaje
    // ========================================================================
    CWPSTRUCT* msg = (CWPSTRUCT*)lParam;

    if (!msg) {
        return CallNextHookEx(g_hHook, code, wParam, lParam);
    }

    // ========================================================================
    // Procesar mensaje WM_CREATE (creación de ventana)
    // ========================================================================
    if (msg->message == WM_CREATE) {
        if (!IsWindow(msg->hwnd)) {
            return CallNextHookEx(g_hHook, code, wParam, lParam);
        }

        wchar_t className[256] = {};

        // Obtener nombre de clase de la ventana (usando Unicode)
        if (GetClassNameW(msg->hwnd, className, ARRAYSIZE(className)) > 0) {
            // Detectar ventanas de Windows Explorer
            if (wcscmp(className, L"CabinetWClass") == 0) {
                OutputDebugStringW(L"[DWM Hook] Detectada ventana CabinetWClass (Explorer)\n");
                ApplyLiquidGlass(msg->hwnd);
            }
        }
    }

    // ========================================================================
    // Procesar mensaje WM_SIZE (cambio de tamaño)
    // ========================================================================
    // Nota: Se puede usar para re-aplicar el efecto si es necesario
    // if (msg->message == WM_SIZE) { ... }

    // Continuar con el siguiente hook en la cadena
    return CallNextHookEx(g_hHook, code, wParam, lParam);
}

// ============================================================================
// FUNCIÓN: InstallHook
// Instala el hook para monitorear ventanas
// ============================================================================
bool InstallHook() {
    if (g_hHook) {
        OutputDebugStringA("[DWM Hook] Advertencia: Hook ya está instalado\n");
        return true;
    }

    // Obtener el thread ID actual
    DWORD threadId = GetCurrentThreadId();

    // Instalar hook de tipo WH_CALLWNDPROC
    g_hHook = SetWindowsHookExA(WH_CALLWNDPROC, HookProc, NULL, threadId);

    if (!g_hHook) {
        OutputDebugStringA("[DWM Hook] Error: No se pudo instalar el hook\n");
        return false;
    }

    OutputDebugStringA("[DWM Hook] Hook instalado exitosamente\n");
    return true;
}

// ============================================================================
// FUNCIÓN: UninstallHook
// Desinstala el hook previamente instalado
// ============================================================================
bool UninstallHook() {
    if (!g_hHook) {
        OutputDebugStringA("[DWM Hook] Advertencia: No hay hook instalado\n");
        return true;
    }

    if (!UnhookWindowsHookEx(g_hHook)) {
        OutputDebugStringA("[DWM Hook] Error: No se pudo desinstalar el hook\n");
        return false;
    }

    g_hHook = NULL;
    OutputDebugStringA("[DWM Hook] Hook desinstalado exitosamente\n");
    return true;
}

// ============================================================================
// FIN DEL ARCHIVO
// ============================================================================