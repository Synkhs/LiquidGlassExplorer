// ============================================================================
// LiquidGlass Explorer - Header del Hook DWM
// ============================================================================
// Define las funciones necesarias para aplicar el efecto Liquid Glass a
// ventanas de Windows Explorer mediante hooks en el Desktop Window Manager.
// ============================================================================

#pragma once

#include <windows.h>

// ============================================================================
// CONSTANTES Y DEFINICIONES
// ============================================================================

/// Handle global del hook (usado para desinstalación)
extern HHOOK g_hHook;

// ============================================================================
// DECLARACIONES DE FUNCIONES
// ============================================================================

/// <summary>
/// Aplica el efecto Liquid Glass a una ventana de Windows Explorer
/// </summary>
/// <param name="hwnd">
/// Handle de la ventana a la que aplicar el efecto
/// </param>
/// <returns>
/// void (los errores se registran en debug)
/// </returns>
/// <remarks>
/// Esta función:
/// - Valida que la ventana exista
/// - Obtiene propiedades de la ventana
/// - Aplica el efecto acrílico/blur mediante composición DWM
/// - Registra errores en OutputDebugString
/// 
/// Nota: Requiere Windows 10 Build 17134 o superior para efectos acrílicos
/// </remarks>
void ApplyLiquidGlass(HWND hwnd);

/// <summary>
/// Procedimiento de hook para interceptar mensajes de ventanas
/// </summary>
/// <param name="code">
/// Código del hook (HC_ACTION = 0 indica que se debe procesar el mensaje)
/// </param>
/// <param name="wParam">
/// No utilizado en hooks de llamada a ventana (WH_CALLWNDPROC)
/// </param>
/// <param name="lParam">
/// Puntero a estructura CWPSTRUCT que contiene información del mensaje
/// Estructura: { HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam }
/// </param>
/// <returns>
/// Resultado del siguiente hook en la cadena (siempre retorna
/// CallNextHookEx para permitir que otros hooks procesen el mensaje)
/// </returns>
/// <remarks>
/// Este hook intercepta todos los mensajes de ventanas enviados a threads.
/// Detecta ventanas de Windows Explorer (clase "CabinetWClass") cuando se
/// crean (mensaje WM_CREATE) y les aplica el efecto Liquid Glass.
/// 
/// El hook se instala globalmente a nivel de thread para monitorear:
/// - Creación de nuevas ventanas de Explorer (WM_CREATE)
/// - Cambios de tamaño (WM_SIZE) - potencial mejora futura
/// - Otros mensajes relevantes
/// 
/// Pasos del hook:
/// 1. Valida que code >= 0
/// 2. Obtiene información de CWPSTRUCT
/// 3. Verifica si es WM_CREATE
/// 4. Obtiene nombre de clase de la ventana
/// 5. Si es "CabinetWClass", aplica LiquidGlass
/// 6. Continúa con el siguiente hook en la cadena
/// </remarks>
LRESULT CALLBACK HookProc(int code, WPARAM wParam, LPARAM lParam);

// ============================================================================
// FUNCIONES DE GESTIÓN DEL HOOK (Declaraciones)
// ============================================================================

/// <summary>
/// Instala el hook para monitorear ventanas
/// </summary>
/// <returns>true si el hook se instaló exitosamente</returns>
bool InstallHook();

/// <summary>
/// Desinstala el hook previamente instalado
/// </summary>
/// <returns>true si el hook se desinstaló exitosamente</returns>
bool UninstallHook();

// ============================================================================
// ESTRUCTURAS Y DEFINICIONES AVANZADAS
// ============================================================================

/// Información del efecto Liquid Glass
struct LiquidGlassConfig {
    float blurStrength;     ///< Intensidad del blur (0.0 - 1.0)
    DWORD tintColor;        ///< Color de tinte (ARGB)
    float tintOpacity;      ///< Opacidad del tinte (0.0 - 1.0)
    bool enableNoise;       ///< Habilitar textura/ruido
    float micaMix;          ///< Mezcla de Mica (0.0 - 1.0)
};

// ============================================================================
// FIN DEL HEADER
// ============================================================================