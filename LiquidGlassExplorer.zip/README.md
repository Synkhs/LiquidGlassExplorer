# LiquidGlass Explorer

✨ **Efecto "Liquid Glass" para el Explorador de Windows 10/11**

Aplica efectos visuales modernos (Aero Glass, Acrylic, Mica) al Explorador de Windows mediante inyección segura de DLL y modificación de composición visual del Desktop Window Manager (DWM).

![Status](https://img.shields.io/badge/status-active-success)
![Platform](https://img.shields.io/badge/platform-Windows%2010%2B-blue)
![Language](https://img.shields.io/badge/language-C%2B%2B-brightgreen)
![License](https://img.shields.io/badge/license-MIT-green)

---

## ✨ Características

- ✅ **Blur estilo Aero** - Efecto clásico de desenfoque
- ✅ **Acrylic** - Efecto acrílico moderno (Windows 10+)
- ✅ **Mica/Mica Alt** - Efecto Mica de Windows 11
- ✅ **Transparencia suave** - Efecto de transparencia personalizable
- ✅ **Configuración flexible** - Archivo `liquidglass.ini` editable
- ✅ **Inyección automática** - Se aplica a todas las ventanas de Explorer
- ✅ **Bajo rendimiento** - Usa APIs nativas de Windows
- ✅ **Totalmente reversible** - Se puede desinstalar sin dejar rastros

---

## 🖥️ Requisitos del Sistema

- **Sistema Operativo:** Windows 10 Build 17134 o superior (para Acrylic)
- **Arquitectura:** x64 (64 bits)
- **Permisos:** Administrador (requerido para la inyección)
- **DLLs:** user32.dll (incluida en Windows)

### Versiones Soportadas

| Versión Windows | Blur | Acrylic | Mica | Estado |
|-----------------|------|---------|------|--------|
| Windows 7/8.1   | ✅   | ❌      | ❌   | Parcial |
| Windows 10 (v1709-v1803) | ✅ | ❌ | ❌ | Parcial |
| Windows 10 (v1809+) | ✅ | ✅ | ❌ | **Completo** |
| Windows 11      | ✅   | ✅      | ✅   | **Completo** |

---

## 📁 Estructura del Proyecto
