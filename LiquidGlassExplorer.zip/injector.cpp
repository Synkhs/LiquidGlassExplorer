// ============================================================================
// LiquidGlass Explorer - Implementación del Inyector
// ============================================================================
// Implementa las funciones para obtener el PID de explorer.exe e inyectar
// la DLL en el proceso remoto mediante code injection.
// ============================================================================

#include "injector.h"
#include <stdio.h>

// ============================================================================
// FUNCIÓN: GetExplorerPID
// Obtiene el Process ID de explorer.exe
// ============================================================================
DWORD GetExplorerPID() {
    PROCESSENTRY32 entry = {};
    entry.dwSize = sizeof(PROCESSENTRY32);

    // Crear snapshot de todos los procesos en ejecución
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        OutputDebugStringA("[Injector] Error: No se pudo crear snapshot de procesos\n");
        return 0;
    }

    // Iterar sobre todos los procesos
    if (Process32First(snapshot, &entry)) {
        do {
            // Comparación case-insensitive de nombres de proceso
            if (_stricmp(entry.szExeFile, "explorer.exe") == 0) {
                DWORD pid = entry.th32ProcessID;
                
                char msg[128];
                sprintf_s(msg, sizeof(msg),
                    "[Injector] explorer.exe encontrado con PID: %lu\n", pid);
                OutputDebugStringA(msg);

                CloseHandle(snapshot);
                return pid;
            }
        } while (Process32Next(snapshot, &entry));
    }

    OutputDebugStringA("[Injector] Error: explorer.exe no está en ejecución\n");
    CloseHandle(snapshot);
    return 0;
}

// ============================================================================
// FUNCIÓN: InjectDLL
// Inyecta una DLL en un proceso remoto mediante code injection
// ============================================================================
bool InjectDLL(DWORD pid, const char* dllPath) {
    if (!dllPath || strlen(dllPath) == 0) {
        OutputDebugStringA("[Injector] Error: dllPath es inválida\n");
        return false;
    }

    OutputDebugStringA("[Injector] Iniciando inyección de DLL...\n");

    // ========================================================================
    // PASO 1: Abrir el proceso remoto
    // ========================================================================
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProcess) {
        OutputDebugStringA("[Injector] Error: No se pudo abrir el proceso\n");
        return false;
    }

    OutputDebugStringA("[Injector] Proceso abierto exitosamente\n");

    // ========================================================================
    // PASO 2: Asignar memoria en el proceso remoto
    // ========================================================================
    size_t pathLen = strlen(dllPath) + 1; // +1 para null terminator
    LPVOID alloc = VirtualAllocEx(
        hProcess,
        NULL,
        pathLen,
        MEM_COMMIT | MEM_RESERVE,
        PAGE_READWRITE
    );

    if (!alloc) {
        OutputDebugStringA("[Injector] Error: No se pudo asignar memoria remota\n");
        CloseHandle(hProcess);
        return false;
    }

    char allocMsg[128];
    sprintf_s(allocMsg, sizeof(allocMsg),
        "[Injector] Memoria asignada en proceso remoto (%zu bytes)\n", pathLen);
    OutputDebugStringA(allocMsg);

    // ========================================================================
    // PASO 3: Escribir la ruta del DLL en la memoria remota
    // ========================================================================
    if (!WriteProcessMemory(hProcess, alloc, dllPath, pathLen, NULL)) {
        OutputDebugStringA("[Injector] Error: No se pudo escribir en memoria remota\n");
        VirtualFreeEx(hProcess, alloc, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    OutputDebugStringA("[Injector] Ruta del DLL escrita en memoria remota\n");

    // ========================================================================
    // PASO 4: Crear thread remoto que carga la DLL
    // ========================================================================
    HANDLE hThread = CreateRemoteThread(
        hProcess,
        NULL,
        0,
        (LPTHREAD_START_ROUTINE)LoadLibraryA,
        alloc,
        0,
        NULL
    );

    if (!hThread) {
        OutputDebugStringA("[Injector] Error: No se pudo crear thread remoto\n");
        VirtualFreeEx(hProcess, alloc, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return false;
    }

    OutputDebugStringA("[Injector] Thread remoto creado, esperando finalización...\n");

    // ========================================================================
    // PASO 5: Esperar a que el thread termine
    // ========================================================================
    DWORD result = WaitForSingleObject(hThread, INJECT_TIMEOUT);

    if (result == WAIT_TIMEOUT) {
        OutputDebugStringA("[Injector] Advertencia: Timeout esperando al thread\n");
    } else if (result == WAIT_FAILED) {
        OutputDebugStringA("[Injector] Error: Error al esperar el thread\n");
    } else {
        OutputDebugStringA("[Injector] Thread finalizado correctamente\n");
    }

    // ========================================================================
    // PASO 6: Liberar recursos
    // ========================================================================
    // Obtener el valor de retorno del thread (HMODULE del LoadLibraryA)
    DWORD threadExitCode = 0;
    GetExitCodeThread(hThread, &threadExitCode);

    if (threadExitCode == 0) {
        OutputDebugStringA("[Injector] Advertencia: LoadLibraryA retornó NULL (error en carga)\n");
    }

    // Liberar memoria remota
    if (!VirtualFreeEx(hProcess, alloc, 0, MEM_RELEASE)) {
        OutputDebugStringA("[Injector] Advertencia: Error al liberar memoria remota\n");
    }

    // Cerrar handles
    CloseHandle(hThread);
    CloseHandle(hProcess);

    OutputDebugStringA("[Injector] Inyección completada\n");
    return true; // Se consideró exitosa si el thread se creó
}

// ============================================================================
// FIN DEL ARCHIVO
// ============================================================================