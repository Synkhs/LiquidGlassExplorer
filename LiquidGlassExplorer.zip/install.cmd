@echo off
REM ============================================================================
REM LiquidGlass Explorer - Script de Instalación
REM ============================================================================
REM Este script instala LiquidGlass Explorer inyectando la DLL en Windows
REM Explorer. Requiere permisos de administrador.
REM ============================================================================

setlocal enabledelayedexpansion

REM ============================================================================
REM CONFIGURACIÓN
REM ============================================================================
set "TITLE=LiquidGlass Explorer - Instalador"
set "INJECTOR_EXE=LiquidGlassInjector.exe"
set "CONFIG_DIR=config"
set "CONFIG_FILE=%CONFIG_DIR%\liquidglass.ini"

REM ============================================================================
REM VERIFICAR PERMISOS DE ADMINISTRADOR
REM ============================================================================
title %TITLE%
cls

echo.
echo ==========================================
echo  LiquidGlass Explorer - Instalador
echo ==========================================
echo.

REM Verificar si se ejecuta como administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Este script requiere permisos de administrador.
    echo.
    echo Por favor:
    echo 1. Haz clic derecho en este archivo
    echo 2. Selecciona "Ejecutar como administrador"
    echo.
    pause
    exit /b 1
)

echo [OK] Permisos de administrador verificados
echo.

REM ============================================================================
REM VERIFICAR ARCHIVOS NECESARIOS
REM ============================================================================
echo Verificando archivos necesarios...
echo.

if not exist "%INJECTOR_EXE%" (
    echo [ERROR] No se encontró: %INJECTOR_EXE%
    echo.
    echo Asegúrate de que el archivo está en la misma carpeta que este script.
    echo.
    pause
    exit /b 1
)
echo [OK] %INJECTOR_EXE% encontrado

if not exist "%CONFIG_FILE%" (
    echo [ADVERTENCIA] No se encontró: %CONFIG_FILE%
    echo Se usarán valores por defecto.
) else (
    echo [OK] %CONFIG_FILE% encontrado
)
echo.

REM ============================================================================
REM CERRAR EXPLORER.EXE
REM ============================================================================
echo Preparando sistema...
echo Cerrando Windows Explorer...

taskkill /IM explorer.exe /F >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Windows Explorer cerrado
) else (
    echo [INFO] Explorer no estaba en ejecución
)

REM Esperar a que se cierre completamente
timeout /t 1 /nobreak >nul

echo.

REM ============================================================================
REM EJECUTAR INYECTOR
REM ============================================================================
echo Inyectando LiquidGlass en Explorer...
echo.

call "%INJECTOR_EXE%"

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] La inyección falló.
    echo.
    echo Por favor, verifica:
    echo - Que tienes permisos de administrador
    echo - Que el archivo DLL existe en la carpeta correcta
    echo - Que Windows 10 Build 17134 o superior está instalado
    echo.
    pause
    exit /b 1
)

echo [OK] Inyección completada exitosamente
echo.

REM ============================================================================
REM REINICIAR EXPLORER.EXE
REM ============================================================================
echo Reiniciando Windows Explorer...

REM Esperar un poco antes de reiniciar
timeout /t 2 /nobreak >nul

start explorer.exe

if %errorlevel% equ 0 (
    echo [OK] Windows Explorer reiniciado
) else (
    echo [ADVERTENCIA] No se pudo reiniciar Explorer automáticamente
    echo Por favor, reinicia manualmente presionando Win + E
)

echo.

REM ============================================================================
REM FINALIZACIÓN
REM ============================================================================
echo ==========================================
echo  Instalación Completada
echo ==========================================
echo.
echo LiquidGlass Explorer está activo.
echo.
echo Abre nuevas ventanas de Explorer para ver el efecto.
echo.
pause
exit /b 0

REM ============================================================================
REM FIN DEL SCRIPT
REM ============================================================================