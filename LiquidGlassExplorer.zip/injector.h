// ============================================================================
// LiquidGlass Explorer - Header del Inyector
// ============================================================================
// Define las funciones necesarias para inyectar la DLL en procesos remotos,
// específicamente en Windows Explorer para aplicar los efectos Liquid Glass.
// ============================================================================

#pragma once

#include <windows.h>
#include <tlhelp32.h>

// ============================================================================
// DECLARACIONES DE FUNCIONES
// ============================================================================

/// <summary>
/// Obtiene el Process ID (PID) de explorer.exe
/// </summary>
/// <returns>
/// El PID de explorer.exe si se encuentra, 0 si no está en ejecución
/// </returns>
/// <remarks>
/// Esta función busca en la lista de procesos en ejecución.
/// Retorna el primer explorer.exe encontrado.
/// </remarks>
DWORD GetExplorerPID();

/// <summary>
/// Inyecta una DLL en un proceso remoto mediante inyección de código
/// </summary>
/// <param name="pid">
/// El Process ID del proceso destino (ej: explorer.exe)
/// </param>
/// <param name="dllPath">
/// Ruta absoluta al archivo DLL a inyectar
/// Debe ser una ruta válida y accesible
/// </param>
/// <returns>
/// true si la inyección fue exitosa
/// false si falló (verificar logs de debug para más detalles)
/// </returns>
/// <remarks>
/// Requiere:
/// - Permisos de administrador
/// - El proceso destino debe estar en ejecución
/// - La arquitectura (32/64 bits) debe coincidir
/// - El archivo DLL debe existir en la ruta especificada
/// 
/// Pasos internos:
/// 1. Abre el proceso remoto
/// 2. Asigna memoria en el proceso remoto
/// 3. Escribe la ruta del DLL en esa memoria
/// 4. Crea un thread remoto que carga la DLL
/// 5. Libera los recursos utilizados
/// </remarks>
bool InjectDLL(DWORD pid, const char* dllPath);

// ============================================================================
// CONSTANTES Y DEFINICIONES
// ============================================================================

/// Máximo número de intentos para inyectar
#define MAX_INJECT_RETRIES 3

/// Timeout máximo para la inyección (en milisegundos)
#define INJECT_TIMEOUT 10000

// ============================================================================
// FIN DEL HEADER
// ============================================================================