@echo off
REM ============================================================================
REM LiquidGlass Explorer - Script de Desinstalación
REM ============================================================================
REM Este script desinstala LiquidGlass Explorer y restaura Windows Explorer
REM a su estado normal. Requiere permisos de administrador.
REM ============================================================================

setlocal enabledelayedexpansion

REM ============================================================================
REM CONFIGURACIÓN
REM ============================================================================
set "TITLE=LiquidGlass Explorer - Desinstalador"
set "APPDATA_DIR=%APPDATA%\LiquidGlass"
set "TEMP_DIR=%TEMP%\LiquidGlass"

REM ============================================================================
REM VERIFICAR PERMISOS DE ADMINISTRADOR
REM ============================================================================
title %TITLE%
cls

echo.
echo ==========================================
echo  LiquidGlass Explorer - Desinstalador
echo ==========================================
echo.

REM Verificar si se ejecuta como administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Este script requiere permisos de administrador.
    echo.
    echo Por favor:
    echo 1. Haz clic derecho en este archivo
    echo 2. Selecciona "Ejecutar como administrador"
    echo.
    pause
    exit /b 1
)

echo [OK] Permisos de administrador verificados
echo.

REM ============================================================================
REM CONFIRMACIÓN DE DESINSTALACIÓN
REM ============================================================================
echo ¿Deseas desinstalar LiquidGlass Explorer?
echo.
echo Esto:
echo - Cerrará Windows Explorer
echo - Eliminará archivos temporales
echo - Restaurará Explorer a su estado normal
echo.

set /p CONFIRM="Escribe 's' para continuar o 'n' para cancelar: "
if /i not "%CONFIRM%"=="s" (
    echo.
    echo Desinstalación cancelada.
    echo.
    pause
    exit /b 0
)

echo.

REM ============================================================================
REM CERRAR EXPLORER.EXE
REM ============================================================================
echo Preparando sistema...
echo Cerrando Windows Explorer...

taskkill /IM explorer.exe /F >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Windows Explorer cerrado
) else (
    echo [INFO] Explorer no estaba en ejecución
)

REM Esperar a que se cierre completamente
timeout /t 1 /nobreak >nul

echo.

REM ============================================================================
REM ELIMINAR ARCHIVOS TEMPORALES
REM ============================================================================
echo Eliminando archivos temporales...

REM Eliminar carpeta en APPDATA
if exist "%APPDATA_DIR%" (
    echo Eliminando: %APPDATA_DIR%
    rmdir /s /q "%APPDATA_DIR%" >nul 2>&1
    if %errorlevel% equ 0 (
        echo [OK] Carpeta de datos eliminada
    ) else (
        echo [ADVERTENCIA] No se pudo eliminar completamente %APPDATA_DIR%
    )
) else (
    echo [INFO] No se encontró carpeta de datos
)

REM Eliminar carpeta temporal
if exist "%TEMP_DIR%" (
    echo Eliminando: %TEMP_DIR%
    rmdir /s /q "%TEMP_DIR%" >nul 2>&1
    if %errorlevel% equ 0 (
        echo [OK] Archivos temporales eliminados
    ) else (
        echo [ADVERTENCIA] No se pudo eliminar completamente archivos temporales
    )
) else (
    echo [INFO] No se encontraron archivos temporales
)

REM Limpiar caché del registro (opcional)
REM Esta línea intenta eliminar entradas del registro de LiquidGlass si existen
reg delete "HKCU\Software\LiquidGlass" /f >nul 2>&1

echo.

REM ============================================================================
REM REINICIAR EXPLORER.EXE
REM ============================================================================
echo Reiniciando Windows Explorer...

REM Esperar un poco antes de reiniciar
timeout /t 2 /nobreak >nul

start explorer.exe

if %errorlevel% equ 0 (
    echo [OK] Windows Explorer reiniciado
) else (
    echo [ADVERTENCIA] No se pudo reiniciar Explorer automáticamente
    echo Por favor, reinicia manualmente presionando Win + E
)

echo.

REM ============================================================================
REM FINALIZACIÓN
REM ============================================================================
echo ==========================================
echo  Desinstalación Completada
echo ==========================================
echo.
echo LiquidGlass Explorer ha sido desinstalado.
echo Windows Explorer ha sido restaurado a su estado normal.
echo.
pause
exit /b 0

REM ============================================================================
REM FIN DEL SCRIPT
REM ============================================================================