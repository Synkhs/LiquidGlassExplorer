// ============================================================================
// LiquidGlass Explorer - Header de Estilos de Ventana
// ============================================================================
// Define las funciones para aplicar diferentes efectos visuales a ventanas
// de Windows Explorer, incluyendo blur acrílico, Mica, y transparencia.
// ============================================================================

#pragma once

#include <windows.h>

// ============================================================================
// NAMESPACE: WindowStyle
// Contiene todas las funciones para aplicar estilos visuales a ventanas
// ============================================================================
namespace WindowStyle {

    // ========================================================================
    // FUNCIONES PRINCIPALES
    // ========================================================================

    /// <summary>
    /// Aplica el efecto principal "Liquid Glass" a una ventana
    /// </summary>
    /// <param name="hwnd">
    /// Handle de la ventana a la que aplicar el efecto
    /// Típicamente una ventana de Windows Explorer (CabinetWClass)
    /// </param>
    /// <returns>
    /// void (los errores se registran en OutputDebugString)
    /// </returns>
    /// <remarks>
    /// Este es el efecto principal que combina blur acrílico con un tinte
    /// sutil para crear el aspecto "Liquid Glass".
    /// 
    /// Configuración:
    /// - Acento: ACCENT_ENABLE_ACRYLICBLURBEHIND
    /// - Color de tinte: Blanco (#FFFFFF)
    /// - Opacidad: 15% (150/255)
    /// - Ruido: Habilitado
    /// 
    /// Requiere: Windows 10 Build 17134 o superior
    /// </remarks>
    void EnableBlur(HWND hwnd);

    // ========================================================================
    // VARIANTES OPCIONALES
    // ========================================================================

    /// <summary>
    /// Aplica efecto acrílico personalizado con color y opacidad específicos
    /// </summary>
    /// <param name="hwnd">
    /// Handle de la ventana
    /// </param>
    /// <param name="color">
    /// Color del efecto en formato RGB (0x00RRGGBB)
    /// Ejemplos: 0xFFFFFF (blanco), 0x000000 (negro), 0xFF5733 (naranja)
    /// </param>
    /// <param name="opacity">
    /// Nivel de opacidad (0-255)
    /// 0 = completamente transparente
    /// 255 = completamente opaco
    /// Valor recomendado: 38 (15% del efecto)
    /// </param>
    /// <remarks>
    /// Permite personalizar completamente el efecto acrílico.
    /// El color y opacidad se combinan en el formato ARGB.
    /// 
    /// Ejemplo: EnableAcrylic(hwnd, 0xFFFFFF, 38)
    /// Aplica efecto acrílico blanco con 15% de opacidad
    /// </remarks>
    void EnableAcrylic(HWND hwnd, unsigned int color, int opacity);

    /// <summary>
    /// Aplica el efecto Mica (exclusivo de Windows 11)
    /// </summary>
    /// <param name="hwnd">
    /// Handle de la ventana
    /// </param>
    /// <remarks>
    /// El efecto Mica es más moderno y requiere Windows 11 Build 22000+
    /// En versiones anteriores de Windows, se degrada gracefully.
    /// 
    /// Características:
    /// - Efecto más sutil que acrílico
    /// - Mejor rendimiento en algunos sistemas
    /// - Diseño más moderno y refinado
    /// </remarks>
    void EnableMica(HWND hwnd);

    /// <summary>
    /// Aplica efecto de transparencia simple a una ventana
    /// </summary>
    /// <param name="hwnd">
    /// Handle de la ventana
    /// </param>
    /// <remarks>
    /// Crea un efecto de transparencia básica sin blur.
    /// Útil para ventanas que necesitan ser semi-transparentes
    /// pero sin el efecto de desenfoque.
    /// </remarks>
    void EnableTransparent(HWND hwnd);

    // ========================================================================
    // FUNCIONES UTILITARIAS
    // ========================================================================

    /// <summary>
    /// Aplica propiedades de composición DWM a una ventana
    /// </summary>
    /// <param name="hwnd">
    /// Handle de la ventana
    /// </param>
    /// <param name="accentState">
    /// Estado de acento (ver enumeración ACCENT_STATE)
    /// 0 = ACCENT_DISABLED (deshabilitado)
    /// 1 = ACCENT_ENABLE_GRADIENT (gradiente)
    /// 2 = ACCENT_ENABLE_TRANSPARENTGRADIENT (gradiente transparente)
    /// 3 = ACCENT_ENABLE_BLURBEHIND (blur simple)
    /// 4 = ACCENT_ENABLE_ACRYLICBLURBEHIND (acrylic blur)
    /// 5 = ACCENT_ENABLE_HOSTBACKDROP (host backdrop)
    /// 6 = ACCENT_ENABLE_FLUENT_DARK (fluent dark - Win11)
    /// </param>
    /// <param name="gradientColor">
    /// Color de gradiente en formato ARGB (0xAARRGGBB)
    /// Ejemplo: (150 << 24) | 0xFFFFFF = blanco con 59% opacidad
    /// </param>
    /// <remarks>
    /// Función de bajo nivel que aplica directamente las propiedades DWM.
    /// Se recomienda usar las funciones de alto nivel (EnableBlur, etc.)
    /// a menos que se necesite un control muy específico.
    /// </remarks>
    void ApplyComposition(HWND hwnd, int accentState, unsigned int gradientColor);

    // ========================================================================
    // CONSTANTES
    // ========================================================================

    /// Estados de acento disponibles
    enum ACCENT_STATE {
        ACCENT_DISABLED = 0,
        ACCENT_ENABLE_GRADIENT = 1,
        ACCENT_ENABLE_TRANSPARENTGRADIENT = 2,
        ACCENT_ENABLE_BLURBEHIND = 3,
        ACCENT_ENABLE_ACRYLICBLURBEHIND = 4,
        ACCENT_ENABLE_HOSTBACKDROP = 5,
        ACCENT_ENABLE_FLUENT_DARK = 6
    };

    /// Atributos de composición de ventana
    enum WINDOW_COMPOSITION_ATTRIBUTE {
        WCA_UNDEFINED = -1,
        WCA_ACCENT_POLICY = 19
    };

    // ========================================================================
    // VALORES POR DEFECTO
    // ========================================================================

    /// Color por defecto para Liquid Glass (blanco)
    constexpr unsigned int DEFAULT_LIQUID_COLOR = 0xFFFFFF;

    /// Opacidad por defecto para Liquid Glass (15%)
    constexpr int DEFAULT_LIQUID_OPACITY = 38; // 150/255 * 255 ≈ 150 en formato ARGB

    /// Opacidad por defecto para Mica
    constexpr int DEFAULT_MICA_OPACITY = 200;

    /// Opacidad por defecto para transparencia
    constexpr int DEFAULT_TRANSPARENT_OPACITY = 128;

} // namespace WindowStyle

// ============================================================================
// FIN DEL HEADER
// ============================================================================