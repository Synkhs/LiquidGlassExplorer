// ============================================================================
// LiquidGlass Explorer - Header de Configuración
// ============================================================================
// Define la estructura y funciones para cargar y gestionar la configuración
// del efecto Liquid Glass desde archivos .ini
// ============================================================================

#pragma once

#include <string>

// ============================================================================
// ESTRUCTURA: Config
// Almacena la configuración del efecto Liquid Glass
// ============================================================================
struct Config {
    // ========================================================================
    // MIEMBROS DE DATOS
    // ========================================================================

    /// Tipo de efecto a aplicar: "acrylic", "mica", "blur"
    std::string effectType;

    /// Intensidad del efecto blur (0.0 - 1.0)
    /// 0.0 = sin efecto, 1.0 = máxima intensidad
    float blurStrength;

    /// Opacidad del tinte (0.0 - 1.0)
    /// 0.0 = completamente transparente, 1.0 = completamente opaco
    float tintOpacity;

    /// Color de tinte en formato RGB (0x00RRGGBB)
    /// Ejemplo: 0xFFFFFF (blanco), 0x000000 (negro)
    unsigned int tintColor;

    /// Habilitar textura/ruido en el efecto
    bool enableNoise;

    /// Mezcla de Mica (0.0 - 1.0)
    /// 0.0 = sin Mica, 1.0 = máximo Mica
    float micaMix;

    // ========================================================================
    // MÉTODOS
    // ========================================================================

    /// <summary>
    /// Constructor por defecto - inicializa con valores por defecto
    /// </summary>
    Config();

    /// <summary>
    /// Carga la configuración desde un archivo .ini
    /// </summary>
    /// <param name="path">
    /// Ruta al archivo de configuración (ej: "config/liquidglass.ini")
    /// Puede ser ruta relativa o absoluta
    /// </param>
    /// <returns>
    /// true si la configuración se cargó exitosamente
    /// false si hubo error (archivo no encontrado, formato inválido, etc.)
    /// </returns>
    /// <remarks>
    /// Si el archivo no existe o hay errores de parseo, se usan valores por defecto.
    /// Los errores se registran en OutputDebugString.
    /// 
    /// Formato del archivo .ini esperado:
    /// [Effect]
    /// type = acrylic
    /// blur_strength = 1.0
    /// tint_color = #FFFFFF
    /// tint_opacity = 0.15
    /// noise = true
    /// mica_mix = 0.25
    /// </remarks>
    bool Load(const char* path);

    /// <summary>
    /// Guarda la configuración actual en un archivo .ini
    /// </summary>
    /// <param name="path">
    /// Ruta donde guardar el archivo de configuración
    /// </param>
    /// <returns>
    /// true si se guardó exitosamente, false en caso contrario
    /// </returns>
    bool Save(const char* path) const;

    /// <summary>
    /// Obtiene los valores por defecto de configuración
    /// </summary>
    /// <remarks>
    /// Se llama automáticamente en el constructor.
    /// Valores por defecto:
    /// - effectType: "acrylic"
    /// - blurStrength: 1.0
    /// - tintOpacity: 0.15
    /// - tintColor: 0xFFFFFF (blanco)
    /// - enableNoise: true
    /// - micaMix: 0.25
    /// </remarks>
    void SetDefaults();

    /// <summary>
    /// Valida que los valores de configuración sean correctos
    /// </summary>
    /// <returns>
    /// true si todos los valores son válidos, false en caso contrario
    /// </returns>
    /// <remarks>
    /// Valida que:
    /// - blurStrength está entre 0.0 y 1.0
    /// - tintOpacity está entre 0.0 y 1.0
    /// - micaMix está entre 0.0 y 1.0
    /// - effectType es uno de los valores válidos
    /// </remarks>
    bool Validate() const;

    /// <summary>
    /// Imprime la configuración actual en debug output
    /// </summary>
    void Print() const;
};

// ============================================================================
// FUNCIONES AUXILIARES
// ============================================================================

/// <summary>
/// Convierte una cadena de color hexadecimal a número entero
/// </summary>
/// <param name="hexColor">
/// String con formato "#RRGGBB" o "0xRRGGBB"
/// </param>
/// <returns>
/// Valor entero del color (0x00RRGGBB)
/// Retorna 0xFFFFFF (blanco) si el formato es inválido
/// </returns>
unsigned int ParseHexColor(const std::string& hexColor);

/// <summary>
/// Convierte un número entero de color a string hexadecimal
/// </summary>
/// <param name="color">Valor entero del color (0x00RRGGBB)</param>
/// <returns>String con formato "#RRGGBB"</returns>
std::string ColorToHex(unsigned int color);

// ============================================================================
// CONSTANTES
// ============================================================================

/// Valor por defecto para tipo de efecto
constexpr const char* DEFAULT_EFFECT_TYPE = "acrylic";

/// Valor por defecto para intensidad de blur
constexpr float DEFAULT_BLUR_STRENGTH = 1.0f;

/// Valor por defecto para opacidad de tinte
constexpr float DEFAULT_TINT_OPACITY = 0.15f;

/// Valor por defecto para color de tinte (blanco)
constexpr unsigned int DEFAULT_TINT_COLOR = 0xFFFFFF;

/// Valor por defecto para textura/ruido
constexpr bool DEFAULT_ENABLE_NOISE = true;

/// Valor por defecto para mezcla de Mica
constexpr float DEFAULT_MICA_MIX = 0.25f;

// ============================================================================
// FIN DEL HEADER
// ============================================================================