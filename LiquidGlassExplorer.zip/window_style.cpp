// ============================================================================
// LiquidGlass Explorer - Implementación de Estilos de Ventana
// ============================================================================
// Implementa las funciones para aplicar diferentes efectos visuales a
// ventanas de Windows Explorer (blur acrílico, Mica, transparencia, etc.)
// ============================================================================

#include "window_style.h"
#include <stdio.h>

// ============================================================================
// DEFINICIONES DE ESTRUCTURAS
// ============================================================================

/// Estructura para política de acento visual (efecto acrílico/blur)
typedef struct _ACCENT_POLICY {
    int AccentState;    ///< Estado del acento (0-6, o valores especiales para Mica)
    int AccentFlags;    ///< Flags adicionales (normalmente 0)
    int GradientColor;  ///< Color de gradiente (formato ARGB)
    int AnimationId;    ///< ID de animación (normalmente 0)
} ACCENT_POLICY;

/// Estructura para datos de composición de ventana
typedef struct _WINDOWCOMPOSITIONATTRIBDATA {
    int Attrib;         ///< Atributo a establecer (WCA_ACCENT_POLICY = 19)
    PVOID pvData;       ///< Puntero a los datos (ACCENT_POLICY*)
    SIZE_T cbData;      ///< Tamaño de los datos (sizeof(ACCENT_POLICY))
} WINDOWCOMPOSITIONATTRIBDATA;

/// Puntero a función SetWindowCompositionAttribute (no exportada públicamente)
typedef BOOL(WINAPI* pSetWindowCompositionAttribute)(HWND, WINDOWCOMPOSITIONATTRIBDATA*);

// ============================================================================
// VARIABLES GLOBALES (Cache)
// ============================================================================

/// Cache del puntero a función para evitar búsquedas repetidas
static pSetWindowCompositionAttribute g_pSetWindowCompositionAttribute = NULL;

// ============================================================================
// FUNCIÓN AUXILIAR: Obtener SetWindowCompositionAttribute
// ============================================================================
static pSetWindowCompositionAttribute GetSetWindowCompositionAttribute() {
    // Retornar desde cache si ya existe
    if (g_pSetWindowCompositionAttribute) {
        return g_pSetWindowCompositionAttribute;
    }

    // Cargar user32.dll
    HMODULE hUser = LoadLibraryA("user32.dll");
    if (!hUser) {
        OutputDebugStringA("[WindowStyle] Error: No se pudo cargar user32.dll\n");
        return NULL;
    }

    // Obtener dirección de la función (no está en el archivo .lib oficial)
    pSetWindowCompositionAttribute func =
        (pSetWindowCompositionAttribute)GetProcAddress(hUser, "SetWindowCompositionAttribute");

    if (!func) {
        OutputDebugStringA("[WindowStyle] Error: SetWindowCompositionAttribute no encontrada\n");
        OutputDebugStringA("               Esta función requiere Windows 10 Build 17134+\n");
        FreeLibrary(hUser);
        return NULL;
    }

    // Guardar en cache
    g_pSetWindowCompositionAttribute = func;
    return func;
}

// ============================================================================
// NAMESPACE: WindowStyle
// ============================================================================
namespace WindowStyle {

    // ========================================================================
    // FUNCIÓN: ApplyComposition (Función utilitaria de bajo nivel)
    // Aplica propiedades de composición DWM a una ventana
    // ========================================================================
    void ApplyComposition(HWND hwnd, int accentState, unsigned int gradientColor) {
        // Validación de parámetros
        if (!IsWindow(hwnd)) {
            OutputDebugStringA("[WindowStyle] Error: HWND inválido en ApplyComposition\n");
            return;
        }

        // Obtener función SetWindowCompositionAttribute
        pSetWindowCompositionAttribute SetWindowCompositionAttribute =
            GetSetWindowCompositionAttribute();

        if (!SetWindowCompositionAttribute) {
            OutputDebugStringA("[WindowStyle] Error: No se pudo obtener SetWindowCompositionAttribute\n");
            return;
        }

        // Configurar la política de acento
        ACCENT_POLICY policy = {};
        policy.AccentState = accentState;
        policy.AccentFlags = 0;
        policy.GradientColor = gradientColor;
        policy.AnimationId = 0;

        // Preparar datos de composición
        WINDOWCOMPOSITIONATTRIBDATA data = {};
        data.Attrib = WCA_ACCENT_POLICY;
        data.pvData = &policy;
        data.cbData = sizeof(ACCENT_POLICY);

        // Aplicar la composición
        BOOL result = SetWindowCompositionAttribute(hwnd, &data);

        if (result) {
            wchar_t msg[256];
            swprintf_s(msg, ARRAYSIZE(msg),
                L"[WindowStyle] Composición aplicada (HWND: 0x%p, State: %d, Color: 0x%08X)\n",
                hwnd, accentState, gradientColor);
            OutputDebugStringW(msg);
        } else {
            OutputDebugStringA("[WindowStyle] Advertencia: SetWindowCompositionAttribute retornó FALSE\n");
        }
    }

    // ========================================================================
    // FUNCIÓN: EnableBlur
    // Aplica el efecto principal "Liquid Glass"
    // ========================================================================
    void EnableBlur(HWND hwnd) {
        if (!IsWindow(hwnd)) {
            OutputDebugStringA("[WindowStyle] Error: HWND inválido en EnableBlur\n");
            return;
        }

        OutputDebugStringA("[WindowStyle] Aplicando efecto Liquid Glass Blur...\n");

        // Usar ACCENT_ENABLE_BLURBEHIND (estado 3)
        // Color: Blanco (#FFFFFF) con opacidad de ~47% (120/255)
        unsigned int gradientColor = (120 << 24) | 0xFFFFFF;

        ApplyComposition(hwnd, ACCENT_ENABLE_BLURBEHIND, gradientColor);
    }

    // ========================================================================
    // FUNCIÓN: EnableAcrylic
    // Aplica efecto acrílico personalizado con color y opacidad
    // ========================================================================
    void EnableAcrylic(HWND hwnd, unsigned int color, int opacity) {
        if (!IsWindow(hwnd)) {
            OutputDebugStringA("[WindowStyle] Error: HWND inválido en EnableAcrylic\n");
            return;
        }

        // Validar parámetros
        if (opacity < 0) opacity = 0;
        if (opacity > 255) opacity = 255;

        color = color & 0xFFFFFF; // Asegurar que sea RGB de 24 bits

        wchar_t msg[256];
        swprintf_s(msg, ARRAYSIZE(msg),
            L"[WindowStyle] Aplicando efecto Acrylic (Color: 0x%06X, Opacidad: %d)\n",
            color, opacity);
        OutputDebugStringW(msg);

        // Crear valor ARGB: (Alpha << 24) | RGB
        unsigned int argb = ((opacity & 0xFF) << 24) | color;

        // Usar ACCENT_ENABLE_ACRYLICBLURBEHIND (estado 4)
        ApplyComposition(hwnd, ACCENT_ENABLE_ACRYLICBLURBEHIND, argb);
    }

    // ========================================================================
    // FUNCIÓN: EnableMica
    // Aplica el efecto Mica (exclusivo de Windows 11)
    // ========================================================================
    void EnableMica(HWND hwnd) {
        if (!IsWindow(hwnd)) {
            OutputDebugStringA("[WindowStyle] Error: HWND inválido en EnableMica\n");
            return;
        }

        OutputDebugStringA("[WindowStyle] Aplicando efecto Mica (Windows 11+)...\n");

        // Nota: El estado 1029 es una constante especial para Mica en Windows 11
        // En versiones anteriores, se degradará a un efecto similar
        unsigned int gradientColor = (80 << 24) | 0xFFFFFF;

        ApplyComposition(hwnd, 1029, gradientColor);
    }

    // ========================================================================
    // FUNCIÓN: EnableTransparent
    // Aplica efecto de transparencia simple
    // ========================================================================
    void EnableTransparent(HWND hwnd) {
        if (!IsWindow(hwnd)) {
            OutputDebugStringA("[WindowStyle] Error: HWND inválido en EnableTransparent\n");
            return;
        }

        OutputDebugStringA("[WindowStyle] Aplicando efecto Transparente...\n");

        // Usar ACCENT_ENABLE_TRANSPARENTGRADIENT (estado 2)
        // Color completamente transparente
        unsigned int gradientColor = 0x00000000;

        ApplyComposition(hwnd, ACCENT_ENABLE_TRANSPARENTGRADIENT, gradientColor);
    }

} // namespace WindowStyle

// ============================================================================
// FIN DEL ARCHIVO
// ============================================================================