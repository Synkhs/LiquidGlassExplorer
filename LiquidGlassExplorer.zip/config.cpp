// ============================================================================
// LiquidGlass Explorer - Implementación de Configuración
// ============================================================================
// Implementa las funciones para cargar, guardar y gestionar la configuración
// del efecto Liquid Glass desde archivos .ini
// ============================================================================

#include "config.h"
#include <windows.h>
#include <stdio.h>
#include <cctype>
#include <algorithm>

// ============================================================================
// CONSTRUCTOR
// ============================================================================
Config::Config() {
    SetDefaults();
}

// ============================================================================
// FUNCIÓN: SetDefaults
// Establece los valores por defecto
// ============================================================================
void Config::SetDefaults() {
    effectType = DEFAULT_EFFECT_TYPE;
    blurStrength = DEFAULT_BLUR_STRENGTH;
    tintOpacity = DEFAULT_TINT_OPACITY;
    tintColor = DEFAULT_TINT_COLOR;
    enableNoise = DEFAULT_ENABLE_NOISE;
    micaMix = DEFAULT_MICA_MIX;

    OutputDebugStringA("[Config] Valores por defecto establecidos\n");
}

// ============================================================================
// FUNCIÓN: Load
// Carga la configuración desde un archivo .ini
// ============================================================================
bool Config::Load(const char* path) {
    if (!path || strlen(path) == 0) {
        OutputDebugStringA("[Config] Error: Ruta de configuración inválida\n");
        SetDefaults();
        return false;
    }

    // Verificar que el archivo existe
    DWORD attribs = GetFileAttributesA(path);
    if (attribs == INVALID_FILE_ATTRIBUTES) {
        char errMsg[512];
        sprintf_s(errMsg, sizeof(errMsg),
            "[Config] Error: Archivo no encontrado: %s\n", path);
        OutputDebugStringA(errMsg);
        SetDefaults();
        return false;
    }

    OutputDebugStringA("[Config] Cargando configuración...\n");

    // ========================================================================
    // Cargar tipo de efecto
    // ========================================================================
    char buffer[256] = {};
    GetPrivateProfileStringA(
        "Effect",
        "type",
        DEFAULT_EFFECT_TYPE,
        buffer,
        ARRAYSIZE(buffer),
        path
    );
    effectType = buffer;

    // Convertir a minúsculas
    std::transform(effectType.begin(), effectType.end(),
        effectType.begin(), ::tolower);

    char typeMsg[128];
    sprintf_s(typeMsg, sizeof(typeMsg),
        "[Config] Tipo de efecto: %s\n", effectType.c_str());
    OutputDebugStringA(typeMsg);

    // ========================================================================
    // Cargar intensidad de blur
    // ========================================================================
    int blurInt = GetPrivateProfileIntA(
        "Effect",
        "blur_strength",
        (int)(DEFAULT_BLUR_STRENGTH * 100),
        path
    );
    blurStrength = blurInt / 100.0f;

    // Validar rango
    if (blurStrength < 0.0f) blurStrength = 0.0f;
    if (blurStrength > 1.0f) blurStrength = 1.0f;

    char blurMsg[128];
    sprintf_s(blurMsg, sizeof(blurMsg),
        "[Config] Intensidad de blur: %.2f\n", blurStrength);
    OutputDebugStringA(blurMsg);

    // ========================================================================
    // Cargar opacidad de tinte
    // ========================================================================
    int opacityInt = GetPrivateProfileIntA(
        "Effect",
        "tint_opacity",
        (int)(DEFAULT_TINT_OPACITY * 100),
        path
    );
    tintOpacity = opacityInt / 100.0f;

    // Validar rango
    if (tintOpacity < 0.0f) tintOpacity = 0.0f;
    if (tintOpacity > 1.0f) tintOpacity = 1.0f;

    char opacityMsg[128];
    sprintf_s(opacityMsg, sizeof(opacityMsg),
        "[Config] Opacidad de tinte: %.2f\n", tintOpacity);
    OutputDebugStringA(opacityMsg);

    // ========================================================================
    // Cargar color de tinte (formato hexadecimal)
    // ========================================================================
    memset(buffer, 0, sizeof(buffer));
    GetPrivateProfileStringA(
        "Effect",
        "tint_color",
        "FFFFFF",
        buffer,
        ARRAYSIZE(buffer),
        path
    );

    tintColor = ParseHexColor(buffer);

    char colorMsg[128];
    sprintf_s(colorMsg, sizeof(colorMsg),
        "[Config] Color de tinte: 0x%06X\n", tintColor);
    OutputDebugStringA(colorMsg);

    // ========================================================================
    // Cargar habilitación de ruido
    // ========================================================================
    int noiseInt = GetPrivateProfileIntA(
        "Effect",
        "noise",
        DEFAULT_ENABLE_NOISE ? 1 : 0,
        path
    );
    enableNoise = (noiseInt != 0);

    OutputDebugStringA(enableNoise ?
        "[Config] Ruido/textura: habilitado\n" :
        "[Config] Ruido/textura: deshabilitado\n");

    // ========================================================================
    // Cargar mezcla de Mica
    // ========================================================================
    int micaInt = GetPrivateProfileIntA(
        "Effect",
        "mica_mix",
        (int)(DEFAULT_MICA_MIX * 100),
        path
    );
    micaMix = micaInt / 100.0f;

    // Validar rango
    if (micaMix < 0.0f) micaMix = 0.0f;
    if (micaMix > 1.0f) micaMix = 1.0f;

    char micaMsg[128];
    sprintf_s(micaMsg, sizeof(micaMsg),
        "[Config] Mezcla de Mica: %.2f\n", micaMix);
    OutputDebugStringA(micaMsg);

    // ========================================================================
    // Validar configuración
    // ========================================================================
    if (!Validate()) {
        OutputDebugStringA("[Config] Advertencia: Valores inválidos detectados\n");
    }

    OutputDebugStringA("[Config] Configuración cargada exitosamente\n");
    return true;
}

// ============================================================================
// FUNCIÓN: Save
// Guarda la configuración en un archivo .ini
// ============================================================================
bool Config::Save(const char* path) const {
    if (!path || strlen(path) == 0) {
        OutputDebugStringA("[Config] Error: Ruta de guardado inválida\n");
        return false;
    }

    char intBuffer[32];

    // Guardar tipo de efecto
    if (!WritePrivateProfileStringA(
        "Effect", "type", effectType.c_str(), path)) {
        OutputDebugStringA("[Config] Error: No se pudo guardar tipo de efecto\n");
        return false;
    }

    // Guardar intensidad de blur
    sprintf_s(intBuffer, sizeof(intBuffer), "%.2f", blurStrength);
    WritePrivateProfileStringA("Effect", "blur_strength", intBuffer, path);

    // Guardar opacidad de tinte
    sprintf_s(intBuffer, sizeof(intBuffer), "%.2f", tintOpacity);
    WritePrivateProfileStringA("Effect", "tint_opacity", intBuffer, path);

    // Guardar color de tinte
    char colorBuffer[16];
    sprintf_s(colorBuffer, sizeof(colorBuffer), "#%06X", tintColor);
    WritePrivateProfileStringA("Effect", "tint_color", colorBuffer, path);

    // Guardar ruido
    sprintf_s(intBuffer, sizeof(intBuffer), "%d", enableNoise ? 1 : 0);
    WritePrivateProfileStringA("Effect", "noise", intBuffer, path);

    // Guardar mezcla de Mica
    sprintf_s(intBuffer, sizeof(intBuffer), "%.2f", micaMix);
    WritePrivateProfileStringA("Effect", "mica_mix", intBuffer, path);

    OutputDebugStringA("[Config] Configuración guardada exitosamente\n");
    return true;
}

// ============================================================================
// FUNCIÓN: Validate
// Valida que los valores de configuración sean correctos
// ============================================================================
bool Config::Validate() const {
    bool valid = true;

    // Validar blurStrength
    if (blurStrength < 0.0f || blurStrength > 1.0f) {
        OutputDebugStringA("[Config] Validación: blurStrength fuera de rango\n");
        valid = false;
    }

    // Validar tintOpacity
    if (tintOpacity < 0.0f || tintOpacity > 1.0f) {
        OutputDebugStringA("[Config] Validación: tintOpacity fuera de rango\n");
        valid = false;
    }

    // Validar micaMix
    if (micaMix < 0.0f || micaMix > 1.0f) {
        OutputDebugStringA("[Config] Validación: micaMix fuera de rango\n");
        valid = false;
    }

    // Validar tipo de efecto
    if (effectType != "acrylic" && effectType != "mica" && effectType != "blur") {
        OutputDebugStringA("[Config] Validación: Tipo de efecto inválido\n");
        valid = false;
    }

    return valid;
}

// ============================================================================
// FUNCIÓN: Print
// Imprime la configuración actual en debug output
// ============================================================================
void Config::Print() const {
    OutputDebugStringA("\n========== CONFIGURACIÓN ACTUAL ==========\n");
    
    char buffer[512];
    sprintf_s(buffer, sizeof(buffer),
        "Tipo de efecto: %s\n"
        "Intensidad de blur: %.2f\n"
        "Opacidad de tinte: %.2f\n"
        "Color de tinte: 0x%06X\n"
        "Ruido/textura: %s\n"
        "Mezcla de Mica: %.2f\n"
        "=========================================\n\n",
        effectType.c_str(),
        blurStrength,
        tintOpacity,
        tintColor,
        enableNoise ? "habilitado" : "deshabilitado",
        micaMix
    );
    
    OutputDebugStringA(buffer);
}

// ============================================================================
// FUNCIÓN AUXILIAR: ParseHexColor
// Convierte una cadena hexadecimal a valor entero
// ============================================================================
unsigned int ParseHexColor(const std::string& hexColor) {
    if (hexColor.empty()) {
        return DEFAULT_TINT_COLOR;
    }

    std::string cleanHex = hexColor;

    // Remover '#' o '0x' del principio
    if (cleanHex[0] == '#' || (cleanHex.length() > 1 && cleanHex[0] == '0' && cleanHex[1] == 'x')) {
        cleanHex = cleanHex.substr(cleanHex[0] == '#' ? 1 : 2);
    }

    // Convertir a número
    try {
        unsigned int color = std::stoul(cleanHex, nullptr, 16);
        return color & 0xFFFFFF; // Asegurar que sea RGB de 24 bits
    }
    catch (...) {
        OutputDebugStringA("[Config] Error: Color hexadecimal inválido\n");
        return DEFAULT_TINT_COLOR;
    }
}

// ============================================================================
// FUNCIÓN AUXILIAR: ColorToHex
// Convierte un valor entero de color a string hexadecimal
// ============================================================================
std::string ColorToHex(unsigned int color) {
    char buffer[16];
    sprintf_s(buffer, sizeof(buffer), "#%06X", color & 0xFFFFFF);
    return std::string(buffer);
}

// ============================================================================
// FIN DEL ARCHIVO
// ============================================================================